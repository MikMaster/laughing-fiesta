# Calculadora Medianía (APK 100% Local / Offline)

Calculadora interactiva de interés compuesto por contratos ganaderos diseñada para funcionar **sin internet**, sin base de datos y de forma independiente en cada teléfono Android.

## Cómo generar el archivo `.apk` en GitHub (3 minutos, sin instalar nada en tu PC)

1. Crea un repositorio nuevo en GitHub (puede ser **Público** o **Privado**), por ejemplo `calculadora-mediania`.
2. Descomprime este archivo `.zip` en tu computadora.
3. Sube todo el contenido de la carpeta (incluyendo la carpeta `.github`, `www`, `android-icons`, `package.json` y `capacitor.config.json`) a la raíz del repositorio en la rama `main`.
4. Entra a la pestaña **Actions** de tu repositorio en GitHub. Verás ejecutándose el flujo **Compilar APK Android** (tarda ~2–3 minutos).
5. Cuando aparezca el check verde, entra a esa ejecución, baja hasta **Artifacts** y descarga **`Calculadora-Mediania-APK`**.
6. Descomprime ese archivo y obtendrás **`Calculadora-Mediania.apk`** listo para instalar en tu teléfono y compartir por WhatsApp.
